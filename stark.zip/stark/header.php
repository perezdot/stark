
<!DOCTYPE html>
<html <?php language_attributes();?>>
	<head>
		<!-- FAV ICON -->
		<link rel="shortcut icon" href="images/favicon.ico" type="text/css" />
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Responsive one page HTML template">
		<meta name="author" content="Netcopy">
		<!-- TITLE-->
		<?php wp_head();?>
	</head>