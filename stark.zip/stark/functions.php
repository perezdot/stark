<?php 
   
function theme_setup(){
    add_theme_support('title-tag');
}

add_action("after_setup_theme","theme_setup");

show_admin_bar(false);

function theme_css_js(){
    wp_enqueue_style('bootstrap',get_template_directory_uri().'/css/bootstrap.min.css',['cssstyle'],'1.0.0');
    wp_enqueue_style('font-awesome',get_template_directory_uri().'/css/font-awesome.min.css',[],'1.0.0');
    wp_enqueue_style('owl',get_template_directory_uri().'/css/owl.carousel.min.css',[],'1.0.0');
    wp_enqueue_style('lightbox',get_template_directory_uri().'/css/lightbox.min.css',[],'1.0.0');
    wp_enqueue_style('YTPlayer',get_template_directory_uri().'/css/mb.YTPlayer.min.css',[],'1.0.0');
    wp_enqueue_style('flaticon',get_template_directory_uri().'/css/flaticon.css',[],'1.0.0');
    wp_enqueue_style('animate',get_template_directory_uri().'/css/owl.carousel.min.css',[],'1.0.0');
    wp_enqueue_style('validator',get_template_directory_uri().'/css/validator.min.css',[],'1.0.0');
    wp_enqueue_style('cssstyle',get_template_directory_uri().'/css/style.css',[],'1.0.0');

    wp_enqueue_script('jqueryjs',get_template_directory_uri().'/js/jquery.min.js',[],'1.0.0',true);
    wp_enqueue_script('bootstrapjs',get_template_directory_uri().'/js/bootstrap.min.js',[],'1.0.0',true);
    wp_enqueue_script('owljs',get_template_directory_uri().'/js/owl.carousel.min.js',[],'1.0.0',true);
    wp_enqueue_script('appearjq',get_template_directory_uri().'/js/jquery.appear.js',[],'1.0.0',true);
    wp_enqueue_script('easingjq',get_template_directory_uri().'/js/jquery.easing.min.js',[],'1.0.0',true);
    wp_enqueue_script('stellarjq',get_template_directory_uri().'/js/jquery.stellar.min.js',[],'1.0.0',true);
    wp_enqueue_script('counterupjq',get_template_directory_uri().'/js/jquery.counterup.min.js',[],'1.0.0',true);
    wp_enqueue_script('isotopejs',get_template_directory_uri().'/js/isotope.pkgd.min.js',[],'1.0.0',true);
    wp_enqueue_script('lightboxjs',get_template_directory_uri().'/js/lightbox.min.js',[],'1.0.0',true);
    wp_enqueue_script('YTPlayerjq',get_template_directory_uri().'/js/jquery.mb.YTPlayer.min.js',[],'1.0.0',true);
    wp_enqueue_script('validatorjs',get_template_directory_uri().'/js/validator.min.js',[],'1.0.0',true);
    wp_enqueue_script('themejsjss',get_template_directory_uri().'/js/theme.js',[],'1.0.0',true);
}
add_action('wp_enqueue_scripts','theme_css_js');
