			<!-- Footer Start -->
			<footer class="footer padding-tb-30 primary-section-bg section-typo-white">
				<div class="container">
					<div class="row text-center margin-bottom-20">
						<div class="col-md-12">
							<ul class="nav navbar-nav footer-social">
								<li><a href="#" class="social-facebook"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" class="social-twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" class="social-pinterest"><i class="fa fa-pinterest-p"></i></a></li>
								<li><a href="#" class="social-instagram"><i class="fa fa-instagram"></i></a></li>
								<li><a href="#" class="social-google-plus"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="row text-center">
						<div class="col-md-12">
							<p class="copyright-text">طراحی شده با ❤️ توسط علی پیروزفر  </p>
						</div>
					</div>
				</div>
				<a href="#" class="back-to-top" id="back-to-top"><i class="fa fa-angle-up"></i></a>
			</footer>
			<!-- Footer End -->
		
		<!-- JQUERY LIBRARY -->
		<script src="<?php echo get_template_directory_uri();?>/js/jquery.min.js"></script>
		<!-- BOOTSTRAP JS -->
		<script src="<?php echo get_template_directory_uri();?>/js/bootstrap.min.js"></script>
		<!-- OWL CAROUSEL JS -->
		<script src="<?php echo get_template_directory_uri();?>/js/owl.carousel.min.js"></script>
		<!-- APPEARS JS -->
		<script src="<?php echo get_template_directory_uri();?>/js/jquery.appear.js"></script>
		<!-- EASING JS -->
		<script src="<?php echo get_template_directory_uri();?>/js/jquery.easing.min.js"></script>
		<!-- STELLAR JS -->
		<script src="<?php echo get_template_directory_uri();?>/js/jquery.stellar.min.js"></script>
		<!-- COUNTER JS -->
		<script src="<?php echo get_template_directory_uri();?>/js/jquery.counterup.min.js"></script>
		<!-- ISOTOPE JS -->
		<script src="<?php echo get_template_directory_uri();?>/js/isotope.pkgd.min.js"></script>
		<!-- LIGHTBOX JS -->
		<script src="<?php echo get_template_directory_uri();?>/js/lightbox.min.js"></script>
		<!-- YTPLAYER JS -->
		<script src="<?php echo get_template_directory_uri();?>/js/jquery.mb.YTPlayer.min.js"></script>
		<!-- BOOTSTRAP VALIDATOR JS -->
		<script src="<?php echo get_template_directory_uri();?>/js/validator.min.js"></script>
		<!-- THEME JS -->
		</div><!-- .main-wrap -->
		<?php wp_footer();?>
	</body>
</html>

