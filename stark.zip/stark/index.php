<?php get_header();?>

<body data-spy="scroll" data-offset="62">
	
		<!-- Page Loader -->
		<div class="page-loader"></div>
		
		<div class="main-wrap">
		
			<!-- Fixed Navbar -->
			<nav class="navbar navbar-sticky navbar-transparent">
				<!-- Navbar Transparent Class: navbar-transparent -->
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand primary-logo" href="#"><img class="img-responsive" src="<?php echo get_template_directory_uri();?>/images/logo-theme.png" alt="Logo" /></a>
						<a class="navbar-brand sticky-logo" href="#"><img class="img-responsive" src="<?php echo get_template_directory_uri();?>/images/logo.png" alt="Logo" /></a>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav pull-right">
							<li class="active"><a href="#home">خانه</a></li>
							<li><a href="#about">درباره ما</a></li>
							<li><a href="#service">سرویس ها</a></li>
							<li><a href="#portfolio">نمونه کار ها</a></li>
							<li><a href="#plans">قیمت ها</a></li>
							<li><a href="#blog">وبلاگ</a></li>
							<li><a href="#contact">تماس با ما</a></li>
						</ul>
					</div>
					<!-- /.navbar-collapse -->
				</div>
				<!-- /.container-fluid -->
			</nav>
			<!-- Theme Header Start -->
			<header id="home" class="full-height bg-img" data-src="<?php echo get_template_directory_uri();?>/images/bg/main-demo.jpg">
				<div class="container">
					<div class="row">
						<div class="col-sm-8 col-sm-offset-2 text-center">
							<div class="header-content">
								<div class="header-content-inner">
									<div class="section-title">
										<h1 class="section-title-divider animated zoomIn">طرح <span class="primary-color">مورد علاقه</span> شما</h1>
										<p>راه اندازی بوت استرپ می تواند به شما در ایجاد وب سایت های بهتر با استفاده از چارچوب CSS بوت استرپ کمک کند! فقط قالب خود را بارگیری کرده و بدون هیچ رشته ای شروع به کار کنید!</p>
									</div>
									<a class="btn btn-default btn-xl" href="#about">اطلاعات بیشتر</a> <!-- THEME DEFAULT BUTTON -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
			<!-- Theme Header End -->
			<!-- About Section -->
			<section id="about" class="section-parallax section-typo-white" data-src="<?php echo get_template_directory_uri();?>/images/bg/3.jpg" data-stellar-background-ratio="0.5">
		       	<span class="overlay-section-bg primary-section-bg"></span>
				<div class="container">
					<div class="row">
						<div class="col-sm-10 col-sm-offset-1 text-center">
							<div class="section-title">
								<h2 class="section-title-divider">ما آنچه را که شما نیاز دارید در اختیار داریم!</h2>
								<!-- SECTION TITLE -->
								<p>
                                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز 								</p>
							</div>
							<a class="btn btn-default btn-xl btn-bg-white" href="#">شروع کنید!</a> <!-- THEME DEFAULT BUTTON WITH WHITE BACKGROUND -->
						</div>
					</div>
				</div>
			</section>
			<!-- Who we are -->
			<section>
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<div class="col-inner">
								<div class="section-sub-title">
									<h3 class="under-line">ما کی هستیم</h3>
								</div>
								<p>
                                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز 								</p>
							</div>
							<div class="col-inner">
								<div class="section-sub-title">
									<h3 class="under-line">آنچه ما انجام می دهیم</h3>
								</div>
								<ul class="star-list">
									<li>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </li>
									<li>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </li>
									<li>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </li>
									<li>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </li>
									<li>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </li>
								</ul>
							</div>
							<a class="btn btn-default btn-xl btn-normal margin-top-20" href="#">بیشتر بخوانید</a> <!-- THEME DEFAULT BUTTON WITH NORMAL STYLE -->
						</div>
						<div class="col-md-6 hidden-sm hidden-xs media">
							<img alt="" src="<?php echo get_template_directory_uri();?>/images/about.png" class="img-responsive" />
						</div>
					</div>
				</div>
			</section>
			<!-- About Section End-->
			<!-- Support Section Start -->
			<section class="section-parallax" data-src="<?php echo get_template_directory_uri();?>/images/bg/4.jpg" data-stellar-background-ratio="0.5">
				<span class="overlay-section-bg black-section-bg"></span>
				<div class="container section-typo-white">
					<div class="row">
						<div class="col-sm-10 col-sm-offset-1 text-center">
							<h2 class="inline-content"><span>برای شروع با استارک آماده اید؟</span></h2>
							<!-- SECTION TITLE -->
							<a class="btn btn-default btn-xl btn-inline" href="#">آماده شدن</a>
						</div>
					</div>
				</div>
			</section>
			<!-- Support Section End -->
			<!-- Service Section Start -->
			<section class="padding-bottom-50" id="service">
				<div class="container text-center">
					<div class="row">
						<div class="col-sm-12">
							<div class="section-title">
								<h2 class="section-title-divider primary-divider">خدمات ما</h2>
								<!-- SECTION TITLE -->
								<p>
                                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است 								</p>
							</div>
						</div>
					</div>
					<div class="row service-box-wrap">
						<div class="col-md-3 col-sm-6 service-box-col">
							<figure>
								<div class="service-image">
									<i class="flaticon-screen-1"></i>
								</div>
							</figure>
							<h4 class="service-title title-bordered">طراحی وب</h4>
							<p class="service-content">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
						</div>
						<div class="col-md-3 col-sm-6 service-box-col">
							<figure>
								<div class="service-image">
									<i class="flaticon-smartphone"></i>
								</div>
							</figure>
							<h4 class="service-title title-bordered">توسعه اپلیکیشن</h4>
							<p class="service-content">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
						</div>
						<div class="col-md-3 col-sm-6 service-box-col">
							<figure>
								<div class="service-image">
									<i class="flaticon-snowflake"></i>
								</div>
							</figure>
							<h4 class="service-title title-bordered">دیجیتال مارکتینگ</h4>
							<p class="service-content">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
						</div>
						<div class="col-md-3 col-sm-6 service-box-col">
							<figure>
								<div class="service-image">
									<i class="flaticon-star"></i>
								</div>
							</figure>
							<h4 class="service-title title-bordered">برندینگ</h4>
							<p class="service-content">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
						</div>
					</div>
				</div>
			</section>
			<!-- Service Section End -->
			<!-- Support Section Start -->
			<section class="section-parallax" data-src="<?php echo get_template_directory_uri();?>/images/bg/5.jpg" data-stellar-background-ratio="0.5">
				<span class="overlay-section-bg black-section-bg"></span>
				<div class="container section-typo-white">
					<div class="row">
						<div class="col-sm-10 col-sm-offset-1 text-center">
							<h2 class="inline-content"><span>ما آماده آمدن هستیم</span></h2>
							<!-- SECTION TITLE -->
							<a class="btn btn-default btn-xl btn-bg-white btn-inline" href="#">شروع کنید!</a>
						</div>
					</div>
				</div>
			</section>
			<!-- Support Section End -->
			<!-- Features Section Start -->
			<section class="padding-bottom-50" id="features">
				<div class="container">
					<div class="row text-center">
						<div class="col-sm-12">
							<div class="section-title">
								<h2 class="section-title-divider primary-divider">ویژگی های ما</h2>
								<!-- SECTION TITLE -->
								<p>
                                    لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است 								</p>
							</div>
						</div>
					</div>
					<div class="row margin-bottom-0">
						<div class="col-sm-4">
							<div class="media feature-box">
								<div class="media-left">
									<span class="feature-icon">
									<i class="fa fa-cubes"></i>
									</span>
								</div>
								<div class="media-body">
									<h4 class="media-heading">طراحی UX</h4>
									<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="media feature-box">
								<div class="media-left">
									<span class="feature-icon">
									<i class="fa fa-desktop"></i>
									</span>
								</div>
								<div class="media-body">
									<h4 class="media-heading">طراحی UI</h4>
									<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="media feature-box">
								<div class="media-left">
									<span class="feature-icon">
									<i class="fa fa-bar-chart"></i>
									</span>
								</div>
								<div class="media-body">
									<h4 class="media-heading">کنترل کیفیت</h4>
									<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
								</div>
							</div>
						</div>
					</div>
					<div class="row margin-bottom-0">
						<div class="col-sm-4">
							<div class="media feature-box">
								<div class="media-left">
									<span class="feature-icon">
									<i class="fa fa-fighter-jet"></i>
									</span>
								</div>
								<div class="media-body">
									<h4 class="media-heading">پشتیبانی سئو</h4>
									<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="media feature-box">
								<div class="media-left">
									<span class="feature-icon">
									<i class="fa fa-server"></i>
									</span>
								</div>
								<div class="media-body">
									<h4 class="media-heading">نگهداری سرور</h4>
									<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="media feature-box">
								<div class="media-left">
									<span class="feature-icon">
									<i class="fa fa-code"></i>
									</span>
								</div>
								<div class="media-body">
									<h4 class="media-heading">توسعه کد</h4>
									<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Features Section End -->
			<!-- Counter Section Start -->
			<section class="section-parallax padding-bottom-50" data-src="<?php echo get_template_directory_uri();?>/images/bg/3.jpg" data-stellar-background-ratio="0.5">
				<span class="overlay-section-bg primary-section-bg"></span>
				<div class="container section-typo-white">
					<div class="row text-center">
						<div class="col-md-3 col-sm-6">
							<div class="counter-wrap">
								<span class="counter-icon">
								<i class="flaticon-user"></i>
								</span>
								<h3 class="counter" data-counter="9894">
									9894
								</h3>
								<span class="counter-text">
                                    مشتریان خوشحال
								</span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="counter-wrap">
								<span class="counter-icon">
								<i class="flaticon-wallet"></i>
								</span>
								<h3 class="counter" data-counter="400">
									400
								</h3>
								<span class="counter-text">
                                    پروژه های تکمیل شده
								</span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="counter-wrap">
								<span class="counter-icon">
								<i class="flaticon-trophy"></i>
								</span>
								<h3 class="counter" data-counter="73">
									73
								</h3>
								<span class="counter-text">
                                    برنده جوایز
								</span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="counter-wrap">
								<span class="counter-icon">
								<i class="flaticon-star"></i>
								</span>
								<h3 class="counter" data-counter="580">
									580
								</h3>
								<span class="counter-text">
                                    نقد های کاربران
								</span>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Counter Section End -->
			<!-- Our Works Section Start -->
			<section id="portfolio">
				<div class="container text-center">
					<div class="row">
						<div class="col-sm-12">
							<div class="section-title">
								<h2 class="section-title-divider primary-divider">آثار ما را ببینید</h2>
								<!-- SECTION TITLE -->
								<p>
									لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است  ut labore et dolore magna aliqua.
								</p>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="portfolio-button-set margin-bottom-30">
								<a class="btn btn-default btn-xl btn-normal portfolio filter-active" href="#">همه</a>
								<a class="btn btn-default btn-xl btn-normal portfolio" data-filter=".digital" href="#">دیجیتال</a>
								<a class="btn btn-default btn-xl btn-normal portfolio" data-filter=".creative" href="#">خلاق</a>
								<a class="btn btn-default btn-xl btn-normal portfolio" data-filter=".web-design" href="#">طراحی وب</a>
								<a class="btn btn-default btn-xl btn-normal portfolio" data-filter=".mobile-app" href="#">اپلیکیشن</a>
							</div>
							<div class="grid" data-gutter="20" data-col="3">
								<div class="portfolio-item element-item digital web-design">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/portfolio/1.jpg" class="img-responsive" />
									<div class="portfolio-content">
										<div class="portfolio-content-inner">
											<div class="portfolio-inner">
												<h4><a href="#" class="link-white">صفحه فرود</a></h4>
												<p class="portfolio-description">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </p>
												<p class="portfolio-popup"><a class="link-white" href="images/portfolio/1.jpg" data-lightbox="portfolio" data-title="Landing Page"><span class="fa fa-arrows-alt"></span></a></p>
											</div>
										</div>
									</div>
								</div>
								<div class="portfolio-item element-item creative web-design">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/portfolio/8.gif" class="img-responsive" />
									<div class="portfolio-content">
										<div class="portfolio-content-inner">
											<div class="portfolio-inner">
												<h4><a href="#" class="link-white">طراحی فوق العاده</a></h4>
												<p class="portfolio-description">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </p>
												<p class="portfolio-popup"><a class="link-white" href="images/portfolio/8.gif" data-lightbox="portfolio" data-title="Awesome Design"><span class="fa fa-arrows-alt"></span></a></p>
											</div>
										</div>
									</div>
								</div>
								<div class="portfolio-item element-item digital creative mobile-app">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/portfolio/3.jpg" class="img-responsive" />
									<div class="portfolio-content">
										<div class="portfolio-content-inner">
											<div class="portfolio-inner">
												<h4><a href="#" class="link-white">کد نویسی تمیز</a></h4>
												<p class="portfolio-description">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </p>
												<p class="portfolio-popup"><a class="link-white" href="images/portfolio/3.jpg" data-lightbox="portfolio" data-title="Code Clear"><span class="fa fa-arrows-alt"></span></a></p>
											</div>
										</div>
									</div>
								</div>
								<div class="portfolio-item element-item digital mobile-app">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/portfolio/10.gif" class="img-responsive" />
									<div class="portfolio-content">
										<div class="portfolio-content-inner">
											<div class="portfolio-inner">
												<h4><a href="#" class="link-white">داشبورد کاربر</a></h4>
												<p class="portfolio-description">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </p>
												<p class="portfolio-popup"><a class="link-white" href="images/portfolio/10.gif" data-lightbox="portfolio" data-title="User Dashboard"><span class="fa fa-arrows-alt"></span></a></p>
											</div>
										</div>
									</div>
								</div>
								<div class="portfolio-item element-item creative web-design">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/portfolio/5.jpg" class="img-responsive" />
									<div class="portfolio-content">
										<div class="portfolio-content-inner">
											<div class="portfolio-inner">
												<h4><a href="#" class="link-white">وکتور</a></h4>
												<p class="portfolio-description">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </p>
												<p class="portfolio-popup"><a class="link-white" href="images/portfolio/5.jpg" data-lightbox="portfolio" data-title="Vector Mask"><span class="fa fa-arrows-alt"></span></a></p>
											</div>
										</div>
									</div>
								</div>
								<div class="portfolio-item element-item digital creative">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/portfolio/9.gif" class="img-responsive" />
									<div class="portfolio-content">
										<div class="portfolio-content-inner">
											<div class="portfolio-inner">
												<h4><a href="#" class="link-white">ترافیک را بشکنید</a></h4>
												<p class="portfolio-description">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </p>
												<p class="portfolio-popup"><a class="link-white" href="images/portfolio/9.gif" data-lightbox="portfolio" data-title="Break Traffic"><span class="fa fa-arrows-alt"></span></a></p>
											</div>
										</div>
									</div>
								</div>
								<div class="portfolio-item element-item web-design mobile-app">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/portfolio/7.jpg" class="img-responsive" />
									<div class="portfolio-content">
										<div class="portfolio-content-inner">
											<div class="portfolio-inner">
												<h4><a href="#" class="link-white">طراحی ماکت</a></h4>
												<p class="portfolio-description">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </p>
												<p class="portfolio-popup"><a class="link-white" href="images/portfolio/7.jpg" data-lightbox="portfolio" data-title="Mockup Design"><span class="fa fa-arrows-alt"></span></a></p>
											</div>
										</div>
									</div>
								</div>
								<div class="portfolio-item element-item creative mobile-app">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/portfolio/4.jpg" class="img-responsive" />
									<div class="portfolio-content">
										<div class="portfolio-content-inner">
											<div class="portfolio-inner">
												<h4><a href="#" class="link-white">سرپرستی تیم</a></h4>
												<p class="portfolio-description">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </p>
												<p class="portfolio-popup"><a class="link-white" href="images/portfolio/4.jpg" data-lightbox="portfolio" data-title="Team Lead"><span class="fa fa-arrows-alt"></span></a></p>
											</div>
										</div>
									</div>
								</div>
								<div class="portfolio-item element-item digital web-design">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/portfolio/6.jpg" class="img-responsive" />
									<div class="portfolio-content">
										<div class="portfolio-content-inner">
											<div class="portfolio-inner">
												<h4><a href="#" class="link-white">عکاسی</a></h4>
												<p class="portfolio-description">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ </p>
												<p class="portfolio-popup"><a class="link-white" href="images/portfolio/6.jpg" data-lightbox="portfolio" data-title="Phototgraphy"><span class="fa fa-arrows-alt"></span></a></p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Our Works Section End -->
			<!-- Support Section Start -->
			<section class="section-parallax" data-src="<?php echo get_template_directory_uri();?>/images/bg/2.jpg" data-stellar-background-ratio="0.5">
				<span class="overlay-section-bg black-section-bg"></span>
				<div class="container section-typo-white">
					<div class="row">
						<div class="col-sm-10 col-sm-offset-1 text-center">
							<h2 class="inline-content"><span>ما آماده آمدن هستیم</span></h2>
							<!-- SECTION TITLE -->
							<a class="btn btn-default btn-xl btn-bg-white btn-inline" href="#">شروع کنید!</a>
						</div>
					</div>
				</div>
			</section>
			<!-- Support Section End -->
			<!-- Our Plans Section Start -->
			<section class="padding-bottom-50" id="plans">
				<div class="container">
					<div class="row text-center">
						<div class="col-sm-12">
							<div class="section-title">
								<h2 class="section-title-divider primary-divider">برنامه های نهایی ما</h2>
								<!-- SECTION TITLE -->
								<p>
									لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است  ut labore et dolore magna aliqua.
								</p>
							</div>
						</div>
					</div>
					<div class="row text-center">
						<div class="col-md-3 col-md-offset-1 animated" data-animation="fadeInUp" data-animation-delay="100">
							<div class="pricing-table">
								<div class="price-main">
									<div class="price-amount">
										<h3>$39<br /><span>/m</span></h3>
									</div>
									<div class="price-title">
										<h2>شروع کننده</h2>
									</div>
									<div class="price-content">
										<p><strong>1</strong> Domain</p>
										<p><strong>100GB</strong> Disk Space</p>
										<p><strong>Unlimited</strong> Bandwidth</p>
										<p>SSL Certificate</p>
										<p><strong>10</strong> Email</p>
										<p><strong>24/7</strong> Support</p>
										<p class="text-center"><a class="btn btn-default btn-xl btn-normal" href="#">اکنون سفارش دهید</a></p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4 animated" data-animation="fadeInUp" data-animation-delay="0">
							<div class="pricing-table featured">
								<div class="price-main">
									<div class="price-amount">
										<h3>$39<br /><span>/m</span></h3>
									</div>
									<div class="price-title">
										<h2>کسب و کار</h2>
									</div>
									<div class="price-content">
										<p><strong>1</strong> Domain</p>
										<p><strong>100GB</strong> Disk Space</p>
										<p><strong>Unlimited</strong> Bandwidth</p>
										<p>SSL Certificate</p>
										<p><strong>10</strong> Email</p>
										<p><strong>24/7</strong> Support</p>
										<p class="text-center"><a class="btn btn-default btn-xl btn-normal" href="#">اکنون سفارش دهید</a></p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3 animated" data-animation="fadeInUp" data-animation-delay="200">
							<div class="pricing-table">
								<div class="price-main">
									<div class="price-amount">
										<h3>$39<br /><span>/m</span></h3>
									</div>
									<div class="price-title">
										<h2>ویژه</h2>
									</div>
									<div class="price-content">
										<p><strong>1</strong> Domain</p>
										<p><strong>100GB</strong> Disk Space</p>
										<p><strong>Unlimited</strong> Bandwidth</p>
										<p>SSL Certificate</p>
										<p><strong>10</strong> Email</p>
										<p><strong>24/7</strong> Support</p>
										<p class="text-center"><a class="btn btn-default btn-xl btn-normal" href="#">اکنون سفارش دهید</a></p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Our Plans Section End -->
			<!-- Support Section Start -->
			<section class="section-parallax" data-src="<?php echo get_template_directory_uri();?>/images/bg/6.jpg" data-stellar-background-ratio="0.5">
				<span class="overlay-section-bg primary-section-bg"></span>
				<div class="container section-typo-white">
					<div class="row">
						<div class="col-sm-10 col-sm-offset-1 text-center">
							<h2 class="inline-content"><span>ما آماده آمدن هستیم</span></h2>
							<!-- SECTION TITLE -->
							<a class="btn btn-default btn-xl btn-bg-white btn-inline" href="#">شروع کنید!</a>
						</div>
					</div>
				</div>
			</section>
			<!-- Support Section End -->
			<!-- Team Section Start -->
			<section class="padding-bottom-50" id="team">
				<div class="container">
					<div class="row text-center">
						<div class="col-sm-12">
							<div class="section-title">
								<h2 class="section-title-divider primary-divider">با تیم ما ملاقات کنید</h2>
								<!-- SECTION TITLE -->
								<p>
									لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است  
								</p>
							</div>
						</div>
					</div>
					<div class="row text-center">
						<div class="col-md-3 col-sm-6">
							<div class="team-wrap text-center">
								<div class="team-image">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/team/1.jpg" title="Jack" class="img-responsive" />
								</div>
								<div class="team-title">
									<h3>نام کارمند</h3>
									<span>سمت کارمند</span>
								</div>
								<div class="team-content">
									لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ 
								</div>
								<div class="team-social-links">
									<ul class="list-inline">
										<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="team-wrap text-center">
								<div class="team-image">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/team/2.jpg" title="Jack" class="img-responsive" />
								</div>
								<div class="team-title">
									<h3>نام کارمند</h3>
									<span>سمت کارمند</span>
								</div>
								<div class="team-content">
									لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ 
								</div>
								<div class="team-social-links">
									<ul class="list-inline">
										<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="team-wrap text-center">
								<div class="team-image">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/team/3.jpg" title="Jack" class="img-responsive" />
								</div>
								<div class="team-title">
									<h3>نام کارمند</h3>
									<span>سمت کارمند</span>
								</div>
								<div class="team-content">
									لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ 
								</div>
								<div class="team-social-links">
									<ul class="list-inline">
										<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="team-wrap text-center">
								<div class="team-image">
									<img alt="" src="<?php echo get_template_directory_uri();?>/images/team/4.jpg" title="Jack" class="img-responsive" />
								</div>
								<div class="team-title">
									<h3>نام کارمند</h3>
									<span>سمت کارمند</span>
								</div>
								<div class="team-content">
									لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ 
								</div>
								<div class="team-social-links">
									<ul class="list-inline">
										<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Team Section End -->
			<!-- Testimonial Section Start -->
			<section class="section-parallax section-typo-white" data-src="<?php echo get_template_directory_uri();?>/images/bg/1.jpg" data-stellar-background-ratio="0.5">
				<span class="overlay-section-bg black-section-bg"></span>
				<div class="container section-typo-white">
					<div class="row">
						<div dir="ltr" class="col-sm-8 col-sm-offset-2 text-center">
							<div class="testimonial-wrapper">
								<div class="owl-carousel white-dots testimonial-slider" data-items="1" data-loop="true" data-slideby="1" data-margin="0" data-nav="false" data-dots="true" data-smart-speed="1000" data-left-arrow="fa fa-angle-left" data-right-arrow="fa fa-angle-right">
									<div class="testimonial-item">
										<div class="testimonial-title">
											<div class="testimonial-image img-thumbnail">
												<img alt="" src="<?php echo get_template_directory_uri();?>/images/testimonial/1.jpg" class="img-responsive" title="Testimonial" />
											</div>
											<h4>نام مشتری</h4>
											<span>سمت مشتری</span>
										</div>
										<div class="testimonial-content">
											<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است </p>
										</div>
									</div>
									<div class="testimonial-item">
										<div class="testimonial-title">
											<div class="testimonial-image img-thumbnail">
												<img alt="" src="<?php echo get_template_directory_uri();?>/images/testimonial/2.jpg" class="img-responsive" title="Testimonial" />
											</div>
											<h4>نام مشتری</h4>
											<span>سمت مشتری</span>
										</div>
										<div class="testimonial-content">
											<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است  </p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Testimonial Section End -->
			<!-- Blog Section Start -->
			<section class="padding-bottom-50" id="blog">
				<div class="container">
					<div class="row text-center">
						<div class="col-sm-12">
							<div class="section-title">
								<h2 class="section-title-divider primary-divider">آخرین مطالب</h2>
								<!-- SECTION TITLE -->
								<p>
									لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است  
								</p>
							</div>
						</div>
					</div>
					<div class="row margin-bottom-0">
						<?php 
						if(have_posts()){
							$i=0;
							while($i <= 2){
								the_post();
								$i++;
							?>
						<div class="col-md-4">
							<div class="blog-wrap">
							<a href="<?php the_permalink();?>">	<div class="blog-image">
						<img alt="" src="<?php the_post_thumbnail_url('small-thumbnail')?>" title="Jack" class="img-responsive"/>
							</div>
							</a>
								<div class="blog-data">
									<div class="blog-meta">
										<ul class="list-inline">
											<li><a href="#" title="Author" class="author"><?php the_author();?></a></li>
											<li><a href="#" title="Date" class="date"><?php the_date();?></a></li>
											<li><a href="#" title="Comments" class="comment">4</a></li>
										</ul>
									</div>
									<div class="blog-title">
										<h3><a href="#" title="Title Here"><?php the_title();?></a></h3>
									</div>
									<div class="blog-content">
									<?php the_excerpt()?>
								</div>
									<a class="btn btn-default btn-xl btn-normal margin-top-20" href="#">بیشتر بخوانید</a>
								</div>
							</div>
						</div>
						<?php }
						}
						?>
					</div>
				</div>
			</section>
			<!-- Blog Section End -->
			<!-- Subsribe Section Start -->
			<section class="section-parallax" data-src="<?php echo get_template_directory_uri();?>/images/bg/7.jpg" data-stellar-background-ratio="0.5">
				<span class="overlay-section-bg black-section-bg"></span>
				<div class="container section-typo-white">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 col-sm-10 col-sm-offset-1 text-center">
							<div class="subscribe-form">
								<p id="subscribe-status-msg" class="hide"></p>
								<form id="subscribe-form" class="subscribe-form" action="#">
									<div class="input-group subscribe-box">
										<input type="text" class="form-control" name="mcemail" autocomplete="off" id="mcemail" placeholder="ایمیل شما">
										<span class="input-group-btn">
										<button class="btn btn-default white-border typo-gray subscribe-btn" type="submit">عضویت</button>
										</span>
									</div>
									<!-- /input-group -->
								</form>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Subsribe Section End -->
			<!-- Contact Section Start -->
			<section class="contact-section" id="contact">
				<div class="container">
					<div class="row text-center">
						<div class="col-sm-8 col-sm-offset-2">
							<div class="section-title">
								<h2 class="section-title-divider primary-divider">تماس با ما</h2>
								<!-- SECTION TITLE -->
								<p>
									لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است
								</p>
							</div>
						</div>
					</div>
					<div class="row text-center">
						<div class="col-sm-4">
							<div class="contact-adress">
								<p class="contact-icons"><i class="fa fa-map-marker primary-color"></i></p>
								<div class="padding-tb-20">
									<p>
										ایران<br />
										مشهد
									</p>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="contact-mail">
								<p class="contact-icons"><i class="fa fa-envelope-o primary-color"></i></p>
								<div class="padding-tb-20">
									<p>admin@netcopy.ir</p>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="contact-number">
								<p class="contact-icons"><i class="fa fa-phone primary-color"></i></p>
								<div class="padding-tb-20">
									<p>
										+44 222 1234<br />
										+44 222 2341
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="row text-center">
						<div class="contact-form">
							<p id="contact-status-msg" class="hide"></p>
							<form id="contact-form" class="contact-form" action="inc/function.php">
								<div class="col-md-4 col-md-offset-2 padding-bottom-20">
									<div class="form-group">
										<input id="name" class="form-control" name="name" autocomplete="off" placeholder="نام" data-bv-field="name" type="text" />
									</div>
								</div>
								<div class="col-md-4 padding-bottom-20">
									<div class="form-group">
										<input id="email" class="form-control" name="email" autocomplete="off" placeholder="ایمیل" data-bv-field="email" type="email">
									</div>
								</div>
								<span class="clearfix"></span>
								<div class="contact-message col-md-8 col-md-offset-2">
									<div class="form-group margin-bottom-0">
										<textarea id="message" class="form-control textarea" rows="3" name="message" placeholder="پیام" data-bv-field="message"></textarea>
									</div>
								</div>
								<div class="col-md-12 padding-top-30">
									<button type="submit" class="btn btn-default btn-xl btn-normal margin-top-20 contact-btn">ارسال پیام</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</section>
			<!-- Contact Section End -->
			<!-- Map Section Start -->
			<section class="padding-none">
				<!-- Map Styles -> Standard, Aubergine, Silver, Retro, Dark, Aubergine -->
				<div id="starkGoogleMap"  style="width:100%;height:400px;" data-map-style="Silver"></div>
			</section>
			<!-- Map Section End -->
			<!-- Our Clients Section Start -->
			<section class="padding-tb-40">
				<div class="container">
					<div class="row">
						<div dir="ltr" class="col-md-12">
							<div class="client-slider-wrap">
								<div class="owl-carousel client-slider" data-items="5" data-loop="true" data-margin="30" data-nav="false" data-slideby="1" data-dots="false" data-smart-speed="1000" data-left-arrow="fa fa-angle-left" data-right-arrow="fa fa-angle-right">
									<div class="client-item">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo get_template_directory_uri();?>/images/clients/1.png" /></a>
									</div>
									<div class="client-item">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo get_template_directory_uri();?>/images/clients/2.png" /></a>
									</div>
									<div class="client-item">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo get_template_directory_uri();?>/images/clients/3.png" /></a>
									</div>
									<div class="client-item">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo get_template_directory_uri();?>/images/clients/4.png" /></a>
									</div>
									<div class="client-item">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo get_template_directory_uri();?>/images/clients/5.png" /></a>
									</div>
									<div class="client-item">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo get_template_directory_uri();?>/images/clients/6.png" /></a>
									</div>
									<div class="client-item">
										<a href="#"><img alt="" class="img-responsive" src="<?php echo get_template_directory_uri();?>/images/clients/7.png" /></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- Our Clients Section End -->
<?php get_footer();?>